# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'DockWidget_simple.ui'
#
# Created: Mon Dec 14 17:35:44 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_DockWidget_simple(object):
    def setupUi(self, DockWidget_simple):
        DockWidget_simple.setObjectName("DockWidget_simple")
        DockWidget_simple.resize(346, 326)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Maximum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(DockWidget_simple.sizePolicy().hasHeightForWidth())
        DockWidget_simple.setSizePolicy(sizePolicy)
        DockWidget_simple.setMinimumSize(QtCore.QSize(346, 268))
        self.dockWidgetContents = QtGui.QWidget()
        self.dockWidgetContents.setObjectName("dockWidgetContents")
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.dockWidgetContents)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.startRecording_button = QtGui.QPushButton(self.dockWidgetContents)
        self.startRecording_button.setMinimumSize(QtCore.QSize(0, 50))
        self.startRecording_button.setCheckable(True)
        self.startRecording_button.setObjectName("startRecording_button")
        self.verticalLayout_2.addWidget(self.startRecording_button)
        self.outputFreeSpace_label = QtGui.QLabel(self.dockWidgetContents)
        self.outputFreeSpace_label.setObjectName("outputFreeSpace_label")
        self.verticalLayout_2.addWidget(self.outputFreeSpace_label)
        self.recording_groupBox = QtGui.QGroupBox(self.dockWidgetContents)
        self.recording_groupBox.setObjectName("recording_groupBox")
        self.verticalLayout = QtGui.QVBoxLayout(self.recording_groupBox)
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setContentsMargins(-1, -1, -1, 0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.gps_widget = GpsStatusWidget(self.recording_groupBox)
        self.gps_widget.setMinimumSize(QtCore.QSize(20, 20))
        self.gps_widget.setMaximumSize(QtCore.QSize(20, 16777215))
        self.gps_widget.setAutoFillBackground(True)
        self.gps_widget.setObjectName("gps_widget")
        self.horizontalLayout.addWidget(self.gps_widget)
        self.gps_label = QtGui.QLabel(self.recording_groupBox)
        self.gps_label.setEnabled(False)
        self.gps_label.setObjectName("gps_label")
        self.horizontalLayout.addWidget(self.gps_label)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.audio_checkBox = QtGui.QCheckBox(self.recording_groupBox)
        self.audio_checkBox.setObjectName("audio_checkBox")
        self.verticalLayout.addWidget(self.audio_checkBox)
        self.video_checkBox = QtGui.QCheckBox(self.recording_groupBox)
        self.video_checkBox.setObjectName("video_checkBox")
        self.verticalLayout.addWidget(self.video_checkBox)
        self.verticalLayout_2.addWidget(self.recording_groupBox)
        self.full_pushButton = QtGui.QPushButton(self.dockWidgetContents)
        self.full_pushButton.setObjectName("full_pushButton")
        self.verticalLayout_2.addWidget(self.full_pushButton)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem)
        DockWidget_simple.setWidget(self.dockWidgetContents)

        self.retranslateUi(DockWidget_simple)
        QtCore.QMetaObject.connectSlotsByName(DockWidget_simple)

    def retranslateUi(self, DockWidget_simple):
        DockWidget_simple.setWindowTitle(QtGui.QApplication.translate("DockWidget_simple", "Data gather plugin", None, QtGui.QApplication.UnicodeUTF8))
        self.startRecording_button.setText(QtGui.QApplication.translate("DockWidget_simple", "Start recording", None, QtGui.QApplication.UnicodeUTF8))
        self.outputFreeSpace_label.setText(QtGui.QApplication.translate("DockWidget_simple", "Free disk space: ? MB", None, QtGui.QApplication.UnicodeUTF8))
        self.recording_groupBox.setTitle(QtGui.QApplication.translate("DockWidget_simple", "Recording sources", None, QtGui.QApplication.UnicodeUTF8))
        self.gps_label.setText(QtGui.QApplication.translate("DockWidget_simple", "GPS fix available (using ? satellites out of ?)", None, QtGui.QApplication.UnicodeUTF8))
        self.audio_checkBox.setText(QtGui.QApplication.translate("DockWidget_simple", "Audio recording", None, QtGui.QApplication.UnicodeUTF8))
        self.video_checkBox.setText(QtGui.QApplication.translate("DockWidget_simple", "Video recording", None, QtGui.QApplication.UnicodeUTF8))
        self.full_pushButton.setText(QtGui.QApplication.translate("DockWidget_simple", "Switch to full interface", None, QtGui.QApplication.UnicodeUTF8))

from GpsStatusWidget import GpsStatusWidget
