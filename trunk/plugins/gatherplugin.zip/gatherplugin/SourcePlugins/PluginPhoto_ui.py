# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginPhoto.ui'
#
# Created: Mon Dec 14 17:35:46 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_PluginPhoto(object):
    def setupUi(self, PluginPhoto):
        PluginPhoto.setObjectName("PluginPhoto")
        PluginPhoto.resize(400, 300)
        self.horizontalLayout_3 = QtGui.QHBoxLayout(PluginPhoto)
        self.horizontalLayout_3.setObjectName("horizontalLayout_3")
        self.verticalLayout_2 = QtGui.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.autoShoot_check = QtGui.QCheckBox(PluginPhoto)
        self.autoShoot_check.setObjectName("autoShoot_check")
        self.verticalLayout_2.addWidget(self.autoShoot_check)
        self.horizontalLayout_2 = QtGui.QHBoxLayout()
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        spacerItem = QtGui.QSpacerItem(20, 20, QtGui.QSizePolicy.Fixed, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout_2.addItem(spacerItem)
        self.verticalLayout = QtGui.QVBoxLayout()
        self.verticalLayout.setObjectName("verticalLayout")
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.autoShootEach_check = QtGui.QCheckBox(PluginPhoto)
        self.autoShootEach_check.setObjectName("autoShootEach_check")
        self.horizontalLayout.addWidget(self.autoShootEach_check)
        self.autoshootEach_edit = QtGui.QLineEdit(PluginPhoto)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.autoshootEach_edit.sizePolicy().hasHeightForWidth())
        self.autoshootEach_edit.setSizePolicy(sizePolicy)
        self.autoshootEach_edit.setMaximumSize(QtCore.QSize(50, 16777215))
        self.autoshootEach_edit.setObjectName("autoshootEach_edit")
        self.horizontalLayout.addWidget(self.autoshootEach_edit)
        self.autoShootEach_label = QtGui.QLabel(PluginPhoto)
        self.autoShootEach_label.setObjectName("autoShootEach_label")
        self.horizontalLayout.addWidget(self.autoShootEach_label)
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.verticalLayout.addLayout(self.horizontalLayout)
        self.autoShootWhenNonsilent_check = QtGui.QCheckBox(PluginPhoto)
        self.autoShootWhenNonsilent_check.setObjectName("autoShootWhenNonsilent_check")
        self.verticalLayout.addWidget(self.autoShootWhenNonsilent_check)
        self.horizontalLayout_2.addLayout(self.verticalLayout)
        self.verticalLayout_2.addLayout(self.horizontalLayout_2)
        self.takeShot_button = QtGui.QPushButton(PluginPhoto)
        self.takeShot_button.setMinimumSize(QtCore.QSize(0, 50))
        self.takeShot_button.setObjectName("takeShot_button")
        self.verticalLayout_2.addWidget(self.takeShot_button)
        self.line = QtGui.QFrame(PluginPhoto)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName("line")
        self.verticalLayout_2.addWidget(self.line)
        self.addPictures_button = QtGui.QPushButton(PluginPhoto)
        self.addPictures_button.setMinimumSize(QtCore.QSize(0, 50))
        self.addPictures_button.setObjectName("addPictures_button")
        self.verticalLayout_2.addWidget(self.addPictures_button)
        spacerItem2 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem2)
        self.horizontalLayout_3.addLayout(self.verticalLayout_2)

        self.retranslateUi(PluginPhoto)
        QtCore.QMetaObject.connectSlotsByName(PluginPhoto)

    def retranslateUi(self, PluginPhoto):
        PluginPhoto.setWindowTitle(QtGui.QApplication.translate("PluginPhoto", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.autoShoot_check.setText(QtGui.QApplication.translate("PluginPhoto", "Automatic shooting", None, QtGui.QApplication.UnicodeUTF8))
        self.autoShootEach_check.setText(QtGui.QApplication.translate("PluginPhoto", "Each", None, QtGui.QApplication.UnicodeUTF8))
        self.autoShootEach_label.setText(QtGui.QApplication.translate("PluginPhoto", "Seconds", None, QtGui.QApplication.UnicodeUTF8))
        self.autoShootWhenNonsilent_check.setText(QtGui.QApplication.translate("PluginPhoto", "When audio detects talk", None, QtGui.QApplication.UnicodeUTF8))
        self.takeShot_button.setText(QtGui.QApplication.translate("PluginPhoto", "Take a shot NOW!", None, QtGui.QApplication.UnicodeUTF8))
        self.addPictures_button.setText(QtGui.QApplication.translate("PluginPhoto", "Add pictures from a directory...", None, QtGui.QApplication.UnicodeUTF8))

