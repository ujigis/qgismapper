# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginDummy.ui'
#
# Created: Mon Dec 14 17:35:45 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_PluginDummy(object):
    def setupUi(self, PluginDummy):
        PluginDummy.setObjectName("PluginDummy")
        PluginDummy.resize(297, 179)
        self.verticalLayout = QtGui.QVBoxLayout(PluginDummy)
        self.verticalLayout.setObjectName("verticalLayout")
        self.label = QtGui.QLabel(PluginDummy)
        self.label.setObjectName("label")
        self.verticalLayout.addWidget(self.label)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)

        self.retranslateUi(PluginDummy)
        QtCore.QMetaObject.connectSlotsByName(PluginDummy)

    def retranslateUi(self, PluginDummy):
        PluginDummy.setWindowTitle(QtGui.QApplication.translate("PluginDummy", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("PluginDummy", "No configuration here... :-)", None, QtGui.QApplication.UnicodeUTF8))

