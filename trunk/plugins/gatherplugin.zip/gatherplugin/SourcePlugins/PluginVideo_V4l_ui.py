# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginVideo_V4l.ui'
#
# Created: Fri Nov 20 19:29:11 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_V4LTab_Widget(object):
    def setupUi(self, V4LTab_Widget):
        V4LTab_Widget.setObjectName("V4LTab_Widget")
        V4LTab_Widget.resize(322, 253)
        self.vboxlayout = QtGui.QVBoxLayout(V4LTab_Widget)
        self.vboxlayout.setObjectName("vboxlayout")
        self.filename_groupBox = QtGui.QGroupBox(V4LTab_Widget)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.filename_groupBox.sizePolicy().hasHeightForWidth())
        self.filename_groupBox.setSizePolicy(sizePolicy)
        self.filename_groupBox.setObjectName("filename_groupBox")
        self.filename_layout = QtGui.QVBoxLayout(self.filename_groupBox)
        self.filename_layout.setObjectName("filename_layout")
        self.mode_layout = QtGui.QHBoxLayout()
        self.mode_layout.setObjectName("mode_layout")
        self.label_2 = QtGui.QLabel(self.filename_groupBox)
        self.label_2.setObjectName("label_2")
        self.mode_layout.addWidget(self.label_2)
        self.modes_comboBox = QtGui.QComboBox(self.filename_groupBox)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.modes_comboBox.sizePolicy().hasHeightForWidth())
        self.modes_comboBox.setSizePolicy(sizePolicy)
        self.modes_comboBox.setMinimumSize(QtCore.QSize(200, 0))
        self.modes_comboBox.setEditable(True)
        self.modes_comboBox.setObjectName("modes_comboBox")
        self.mode_layout.addWidget(self.modes_comboBox)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.mode_layout.addItem(spacerItem)
        self.filename_layout.addLayout(self.mode_layout)
        self.videoPreview_checkBox = QtGui.QCheckBox(self.filename_groupBox)
        self.videoPreview_checkBox.setObjectName("videoPreview_checkBox")
        self.filename_layout.addWidget(self.videoPreview_checkBox)
        spacerItem1 = QtGui.QSpacerItem(20, 0, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.filename_layout.addItem(spacerItem1)
        self.vboxlayout.addWidget(self.filename_groupBox)
        self.remove_pushButton = QtGui.QPushButton(V4LTab_Widget)
        self.remove_pushButton.setObjectName("remove_pushButton")
        self.vboxlayout.addWidget(self.remove_pushButton)

        self.retranslateUi(V4LTab_Widget)
        QtCore.QMetaObject.connectSlotsByName(V4LTab_Widget)

    def retranslateUi(self, V4LTab_Widget):
        V4LTab_Widget.setWindowTitle(QtGui.QApplication.translate("V4LTab_Widget", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.filename_groupBox.setTitle(QtGui.QApplication.translate("V4LTab_Widget", "Filename", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("V4LTab_Widget", "Mode:", None, QtGui.QApplication.UnicodeUTF8))
        self.videoPreview_checkBox.setText(QtGui.QApplication.translate("V4LTab_Widget", "Video preview", None, QtGui.QApplication.UnicodeUTF8))
        self.remove_pushButton.setText(QtGui.QApplication.translate("V4LTab_Widget", "Remove camera from used list", None, QtGui.QApplication.UnicodeUTF8))

