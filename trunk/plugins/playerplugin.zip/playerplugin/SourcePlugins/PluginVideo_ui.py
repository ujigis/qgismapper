# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginVideo.ui'
#
# Created: Mon Dec 14 17:35:48 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_PluginVideo(object):
    def setupUi(self, PluginVideo):
        PluginVideo.setObjectName("PluginVideo")
        PluginVideo.resize(297, 179)
        self.verticalLayout = QtGui.QVBoxLayout(PluginVideo)
        self.verticalLayout.setObjectName("verticalLayout")
        self.active_checkBox = QtGui.QCheckBox(PluginVideo)
        self.active_checkBox.setObjectName("active_checkBox")
        self.verticalLayout.addWidget(self.active_checkBox)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtGui.QLabel(PluginVideo)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Maximum, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy)
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        self.records_comboBox = QtGui.QComboBox(PluginVideo)
        self.records_comboBox.setObjectName("records_comboBox")
        self.horizontalLayout.addWidget(self.records_comboBox)
        self.verticalLayout.addLayout(self.horizontalLayout)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)

        self.retranslateUi(PluginVideo)
        QtCore.QMetaObject.connectSlotsByName(PluginVideo)

    def retranslateUi(self, PluginVideo):
        PluginVideo.setWindowTitle(QtGui.QApplication.translate("PluginVideo", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.active_checkBox.setText(QtGui.QApplication.translate("PluginVideo", "Replay active", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("PluginVideo", "Camera:", None, QtGui.QApplication.UnicodeUTF8))

