# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginGps.ui'
#
# Created: Mon Dec 14 17:35:47 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_PluginGps(object):
    def setupUi(self, PluginGps):
        PluginGps.setObjectName("PluginGps")
        PluginGps.resize(297, 241)
        self.verticalLayout = QtGui.QVBoxLayout(PluginGps)
        self.verticalLayout.setObjectName("verticalLayout")
        self.info_treeWidget = QtGui.QTreeWidget(PluginGps)
        self.info_treeWidget.setEnabled(True)
        self.info_treeWidget.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.info_treeWidget.setRootIsDecorated(False)
        self.info_treeWidget.setObjectName("info_treeWidget")
        self.verticalLayout.addWidget(self.info_treeWidget)

        self.retranslateUi(PluginGps)
        QtCore.QMetaObject.connectSlotsByName(PluginGps)

    def retranslateUi(self, PluginGps):
        PluginGps.setWindowTitle(QtGui.QApplication.translate("PluginGps", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.info_treeWidget.headerItem().setText(0, QtGui.QApplication.translate("PluginGps", "Key", None, QtGui.QApplication.UnicodeUTF8))
        self.info_treeWidget.headerItem().setText(1, QtGui.QApplication.translate("PluginGps", "Value", None, QtGui.QApplication.UnicodeUTF8))

