# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginNotes.ui'
#
# Created: Mon Dec 14 17:35:47 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_PluginNotes(object):
    def setupUi(self, PluginNotes):
        PluginNotes.setObjectName("PluginNotes")
        PluginNotes.resize(297, 179)
        self.verticalLayout = QtGui.QVBoxLayout(PluginNotes)
        self.verticalLayout.setObjectName("verticalLayout")
        self.note_label = QtGui.QLabel(PluginNotes)
        self.note_label.setObjectName("note_label")
        self.verticalLayout.addWidget(self.note_label)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)

        self.retranslateUi(PluginNotes)
        QtCore.QMetaObject.connectSlotsByName(PluginNotes)

    def retranslateUi(self, PluginNotes):
        PluginNotes.setWindowTitle(QtGui.QApplication.translate("PluginNotes", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.note_label.setText(QtGui.QApplication.translate("PluginNotes", "...no note selected...", None, QtGui.QApplication.UnicodeUTF8))

