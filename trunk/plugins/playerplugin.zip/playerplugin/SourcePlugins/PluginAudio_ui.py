# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginAudio.ui'
#
# Created: Mon Dec 14 17:35:47 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_PluginAudio(object):
    def setupUi(self, PluginAudio):
        PluginAudio.setObjectName("PluginAudio")
        PluginAudio.resize(297, 179)
        self.verticalLayout = QtGui.QVBoxLayout(PluginAudio)
        self.verticalLayout.setObjectName("verticalLayout")
        self.active_checkBox = QtGui.QCheckBox(PluginAudio)
        self.active_checkBox.setObjectName("active_checkBox")
        self.verticalLayout.addWidget(self.active_checkBox)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.label = QtGui.QLabel(PluginAudio)
        self.label.setObjectName("label")
        self.horizontalLayout.addWidget(self.label)
        self.cboOutputDevice = QtGui.QComboBox(PluginAudio)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Preferred, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(1)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.cboOutputDevice.sizePolicy().hasHeightForWidth())
        self.cboOutputDevice.setSizePolicy(sizePolicy)
        self.cboOutputDevice.setObjectName("cboOutputDevice")
        self.horizontalLayout.addWidget(self.cboOutputDevice)
        self.verticalLayout.addLayout(self.horizontalLayout)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)

        self.retranslateUi(PluginAudio)
        QtCore.QMetaObject.connectSlotsByName(PluginAudio)

    def retranslateUi(self, PluginAudio):
        PluginAudio.setWindowTitle(QtGui.QApplication.translate("PluginAudio", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.active_checkBox.setText(QtGui.QApplication.translate("PluginAudio", "Active", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("PluginAudio", "Output device:", None, QtGui.QApplication.UnicodeUTF8))

