# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginVideo_playerWindow.ui'
#
# Created: Fri Nov 20 19:29:13 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_VideoPlayerWindow(object):
    def setupUi(self, VideoPlayerWindow):
        VideoPlayerWindow.setObjectName("VideoPlayerWindow")
        VideoPlayerWindow.resize(338, 311)
        self.verticalLayout = QtGui.QVBoxLayout(VideoPlayerWindow)
        self.verticalLayout.setObjectName("verticalLayout")
        self.videoView = VideoPlayerWidget(VideoPlayerWindow)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.videoView.sizePolicy().hasHeightForWidth())
        self.videoView.setSizePolicy(sizePolicy)
        self.videoView.setMinimumSize(QtCore.QSize(160, 120))
        self.videoView.setObjectName("videoView")
        self.verticalLayout.addWidget(self.videoView)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setSizeConstraint(QtGui.QLayout.SetDefaultConstraint)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.saveImage_button = QtGui.QPushButton(VideoPlayerWindow)
        self.saveImage_button.setEnabled(False)
        self.saveImage_button.setObjectName("saveImage_button")
        self.horizontalLayout.addWidget(self.saveImage_button)
        self.videoPosition_slider = QtGui.QSlider(VideoPlayerWindow)
        self.videoPosition_slider.setOrientation(QtCore.Qt.Horizontal)
        self.videoPosition_slider.setObjectName("videoPosition_slider")
        self.horizontalLayout.addWidget(self.videoPosition_slider)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.retranslateUi(VideoPlayerWindow)
        QtCore.QMetaObject.connectSlotsByName(VideoPlayerWindow)

    def retranslateUi(self, VideoPlayerWindow):
        VideoPlayerWindow.setWindowTitle(QtGui.QApplication.translate("VideoPlayerWindow", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.saveImage_button.setText(QtGui.QApplication.translate("VideoPlayerWindow", "Save image...", None, QtGui.QApplication.UnicodeUTF8))

from VideoPlayerWidget_mplayer import VideoPlayerWidget
