# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginAudio.ui'
#
# Created: Fri Nov 20 19:29:11 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_PluginAudio(object):
    def setupUi(self, PluginAudio):
        PluginAudio.setObjectName("PluginAudio")
        PluginAudio.resize(297, 179)
        self.verticalLayout = QtGui.QVBoxLayout(PluginAudio)
        self.verticalLayout.setObjectName("verticalLayout")
        self.active_checkBox = QtGui.QCheckBox(PluginAudio)
        self.active_checkBox.setObjectName("active_checkBox")
        self.verticalLayout.addWidget(self.active_checkBox)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)

        self.retranslateUi(PluginAudio)
        QtCore.QMetaObject.connectSlotsByName(PluginAudio)

    def retranslateUi(self, PluginAudio):
        PluginAudio.setWindowTitle(QtGui.QApplication.translate("PluginAudio", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.active_checkBox.setText(QtGui.QApplication.translate("PluginAudio", "Active", None, QtGui.QApplication.UnicodeUTF8))

