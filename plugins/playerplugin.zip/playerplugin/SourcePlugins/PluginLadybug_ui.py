# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginLadybug.ui'
#
# Created: Fri Nov 20 19:29:12 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_PluginLadybug(object):
    def setupUi(self, PluginLadybug):
        PluginLadybug.setObjectName("PluginLadybug")
        PluginLadybug.resize(297, 179)
        self.verticalLayout = QtGui.QVBoxLayout(PluginLadybug)
        self.verticalLayout.setObjectName("verticalLayout")
        self.chkActive = QtGui.QCheckBox(PluginLadybug)
        self.chkActive.setObjectName("chkActive")
        self.verticalLayout.addWidget(self.chkActive)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)

        self.retranslateUi(PluginLadybug)
        QtCore.QMetaObject.connectSlotsByName(PluginLadybug)

    def retranslateUi(self, PluginLadybug):
        PluginLadybug.setWindowTitle(QtGui.QApplication.translate("PluginLadybug", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.chkActive.setText(QtGui.QApplication.translate("PluginLadybug", "active", None, QtGui.QApplication.UnicodeUTF8))

