# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginGps.ui'
#
# Created: Fri Nov 20 19:29:12 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_PluginGps(object):
    def setupUi(self, PluginGps):
        PluginGps.setObjectName("PluginGps")
        PluginGps.resize(297, 241)
        self.verticalLayout = QtGui.QVBoxLayout(PluginGps)
        self.verticalLayout.setObjectName("verticalLayout")
        self.info_tableWidget = QtGui.QTableWidget(PluginGps)
        self.info_tableWidget.setEnabled(True)
        self.info_tableWidget.setEditTriggers(QtGui.QAbstractItemView.NoEditTriggers)
        self.info_tableWidget.setCornerButtonEnabled(False)
        self.info_tableWidget.setColumnCount(2)
        self.info_tableWidget.setObjectName("info_tableWidget")
        self.info_tableWidget.setColumnCount(2)
        self.info_tableWidget.setRowCount(0)
        item = QtGui.QTableWidgetItem()
        self.info_tableWidget.setHorizontalHeaderItem(0, item)
        item = QtGui.QTableWidgetItem()
        self.info_tableWidget.setHorizontalHeaderItem(1, item)
        self.verticalLayout.addWidget(self.info_tableWidget)

        self.retranslateUi(PluginGps)
        QtCore.QMetaObject.connectSlotsByName(PluginGps)

    def retranslateUi(self, PluginGps):
        PluginGps.setWindowTitle(QtGui.QApplication.translate("PluginGps", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.info_tableWidget.horizontalHeaderItem(0).setText(QtGui.QApplication.translate("PluginGps", "Item", None, QtGui.QApplication.UnicodeUTF8))
        self.info_tableWidget.horizontalHeaderItem(1).setText(QtGui.QApplication.translate("PluginGps", "Value", None, QtGui.QApplication.UnicodeUTF8))

