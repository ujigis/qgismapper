# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginAudio.ui'
#
# Created: Thu Dec 17 17:48:46 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_PluginAudio(object):
    def setupUi(self, PluginAudio):
        PluginAudio.setObjectName("PluginAudio")
        PluginAudio.resize(297, 179)
        self.verticalLayout = QtGui.QVBoxLayout(PluginAudio)
        self.verticalLayout.setObjectName("verticalLayout")
        self.recordingEnabled_button = QtGui.QPushButton(PluginAudio)
        self.recordingEnabled_button.setMinimumSize(QtCore.QSize(0, 50))
        self.recordingEnabled_button.setCheckable(True)
        self.recordingEnabled_button.setChecked(False)
        self.recordingEnabled_button.setObjectName("recordingEnabled_button")
        self.verticalLayout.addWidget(self.recordingEnabled_button)
        self.gridLayout = QtGui.QGridLayout()
        self.gridLayout.setObjectName("gridLayout")
        self.label_2 = QtGui.QLabel(PluginAudio)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 0, 0, 1, 1)
        self.cboInputDevice = QtGui.QComboBox(PluginAudio)
        self.cboInputDevice.setObjectName("cboInputDevice")
        self.gridLayout.addWidget(self.cboInputDevice, 0, 1, 1, 1)
        self.label = QtGui.QLabel(PluginAudio)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 1, 0, 1, 1)
        self.audioStatus = AudioStatusWidget(PluginAudio)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.audioStatus.sizePolicy().hasHeightForWidth())
        self.audioStatus.setSizePolicy(sizePolicy)
        self.audioStatus.setMinimumSize(QtCore.QSize(0, 20))
        self.audioStatus.setObjectName("audioStatus")
        self.gridLayout.addWidget(self.audioStatus, 1, 1, 1, 1)
        self.verticalLayout.addLayout(self.gridLayout)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)

        self.retranslateUi(PluginAudio)
        QtCore.QMetaObject.connectSlotsByName(PluginAudio)

    def retranslateUi(self, PluginAudio):
        PluginAudio.setWindowTitle(QtGui.QApplication.translate("PluginAudio", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.recordingEnabled_button.setText(QtGui.QApplication.translate("PluginAudio", "Recording disabled (click to enable)", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("PluginAudio", "Input device:", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("PluginAudio", "Audio peak:", None, QtGui.QApplication.UnicodeUTF8))

from AudioStatusWidget import AudioStatusWidget
