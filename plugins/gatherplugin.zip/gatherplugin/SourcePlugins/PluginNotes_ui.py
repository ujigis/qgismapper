# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginNotes.ui'
#
# Created: Thu Dec 17 17:48:48 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_PluginNotes(object):
    def setupUi(self, PluginNotes):
        PluginNotes.setObjectName("PluginNotes")
        PluginNotes.resize(297, 173)
        self.verticalLayout = QtGui.QVBoxLayout(PluginNotes)
        self.verticalLayout.setObjectName("verticalLayout")
        self.mark_button = QtGui.QPushButton(PluginNotes)
        self.mark_button.setObjectName("mark_button")
        self.verticalLayout.addWidget(self.mark_button)
        self.note_stackedWidget = QtGui.QStackedWidget(PluginNotes)
        self.note_stackedWidget.setObjectName("note_stackedWidget")
        self.page_2 = QtGui.QWidget()
        self.page_2.setObjectName("page_2")
        self.verticalLayout_3 = QtGui.QVBoxLayout(self.page_2)
        self.verticalLayout_3.setObjectName("verticalLayout_3")
        self.label = QtGui.QLabel(self.page_2)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.verticalLayout_3.addWidget(self.label)
        spacerItem = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_3.addItem(spacerItem)
        self.note_stackedWidget.addWidget(self.page_2)
        self.page = QtGui.QWidget()
        self.page.setObjectName("page")
        self.verticalLayout_2 = QtGui.QVBoxLayout(self.page)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.note_lineEdit = QtGui.QLineEdit(self.page)
        self.note_lineEdit.setObjectName("note_lineEdit")
        self.verticalLayout_2.addWidget(self.note_lineEdit)
        self.horizontalLayout = QtGui.QHBoxLayout()
        self.horizontalLayout.setObjectName("horizontalLayout")
        spacerItem1 = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem1)
        self.noteAdd_pushButton = QtGui.QPushButton(self.page)
        self.noteAdd_pushButton.setDefault(False)
        self.noteAdd_pushButton.setObjectName("noteAdd_pushButton")
        self.horizontalLayout.addWidget(self.noteAdd_pushButton)
        self.noNote_pushButton = QtGui.QPushButton(self.page)
        self.noNote_pushButton.setObjectName("noNote_pushButton")
        self.horizontalLayout.addWidget(self.noNote_pushButton)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        spacerItem2 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem2)
        self.note_stackedWidget.addWidget(self.page)
        self.verticalLayout.addWidget(self.note_stackedWidget)
        spacerItem3 = QtGui.QSpacerItem(20, 40, QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem3)

        self.retranslateUi(PluginNotes)
        self.note_stackedWidget.setCurrentIndex(0)
        QtCore.QObject.connect(self.note_lineEdit, QtCore.SIGNAL("returnPressed()"), self.noteAdd_pushButton.click)
        QtCore.QMetaObject.connectSlotsByName(PluginNotes)

    def retranslateUi(self, PluginNotes):
        PluginNotes.setWindowTitle(QtGui.QApplication.translate("PluginNotes", "Form", None, QtGui.QApplication.UnicodeUTF8))
        self.mark_button.setText(QtGui.QApplication.translate("PluginNotes", "Mark current position", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("PluginNotes", "(you\'ll be able to enter a note after marking position)", None, QtGui.QApplication.UnicodeUTF8))
        self.noteAdd_pushButton.setText(QtGui.QApplication.translate("PluginNotes", "Add note", None, QtGui.QApplication.UnicodeUTF8))
        self.noNote_pushButton.setText(QtGui.QApplication.translate("PluginNotes", "No note", None, QtGui.QApplication.UnicodeUTF8))

