# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SourcePlugins/PluginGps.ui'
#
# Created: Thu Dec 17 17:48:47 2009
#      by: PyQt4 UI code generator 4.6
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

class Ui_PluginGps(object):
    def setupUi(self, PluginGps):
        PluginGps.setObjectName("PluginGps")
        PluginGps.resize(297, 240)
        self.verticalLayout = QtGui.QVBoxLayout(PluginGps)
        self.verticalLayout.setObjectName("verticalLayout")
        self.gpsInfo = GpsInfoWidget(PluginGps)
        self.gpsInfo.setObjectName("gpsInfo")
        self.verticalLayout.addWidget(self.gpsInfo)

        self.retranslateUi(PluginGps)
        QtCore.QMetaObject.connectSlotsByName(PluginGps)

    def retranslateUi(self, PluginGps):
        PluginGps.setWindowTitle(QtGui.QApplication.translate("PluginGps", "Form", None, QtGui.QApplication.UnicodeUTF8))

from GpsInfoWidget import GpsInfoWidget
